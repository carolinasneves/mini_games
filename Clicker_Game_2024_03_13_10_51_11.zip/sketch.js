let x = 200
let y = 200
let r = 0
let g = 0
let b = 0
let score = 0
let lives = 3

function setup() {
  createCanvas(400, 400);
  r = (221);
  g = (172);
  b = (252);
}

function draw() {
  background(172, 211, 252);
  fill(r,g,b);
  ellipse(x,y,100,100);
  x = x+1 
  y = y+1
  if(x>= 450 || y>=450)
    {
      x = -80;
      y = random(-10, 300);
    }
  
  fill(0,0,0);
  textSize(20);
  text("Score: " + score, 20, 25);
  text("Lives: " + lives , 280, 25);
  
  if(score >=5)
    {
      background(162, 237, 252);
      fill(255, 255, 255);
      textSize(50);
      text("You Won!", 90, 210);
    }
  if(lives <= 0)
    {
      background(252, 162, 211);
      fill(0, 0, 0);
      textSize(50);
      text("You Lose!", 90, 210);
    }
}

function mousePressed(){
  
  if(abs(mouseX-x)<50 && abs(mouseY-y)<50)
  {
    x = random(400);
    y = random(400);
    r = random(255);
    g = random(255);
    b = random(255);
    score = score + 1;
  }
  else 
    {
      lives = lives - 1; 
    }
}
