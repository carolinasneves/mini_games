let r;
let g; 
let b;

function setup() {
  createCanvas(400, 400);
   background(224, 204, 220);
   noStroke();
   fill(255, 255, 255);
   square(10, 10, 380);
}

function draw() {
  //verde
  stroke(0, 0, 0);
  fill(181, 232, 188);
  square(20, 20, 20);
  
  //rosa
   stroke(0, 0, 0);
  fill(237, 192, 228);
  square(60, 20, 20);
  
  //roxo
   stroke(0, 0, 0);
  fill(193, 171, 237);
  square(100, 20, 20);
  
  //azul
   stroke(0, 0, 0);
  fill(171, 208, 237);
  square(140, 20, 20);
  
  //amarelo
   stroke(0, 0, 0);
  fill(245, 243, 176);
  square(180, 20, 20);
  
  //amarelo
   stroke(0, 0, 0);
  fill(247, 173, 146);
  square(220, 20, 20);
  
   //delete all drawing
  fill(255, 255, 255);
  stroke(0, 0, 0);
  rect(360, 20, 20, 20);
  fill(0, 0, 0);
  textSize(15);
  text('X', 365, 35);
  
  //borracha
  fill(255, 255, 255);
  stroke(0, 0, 0);
  rect(320, 20, 20, 20);
  
  
   if (mouseIsPressed == true){
    noStroke();
    fill(r, g, b);
    circle(mouseX, mouseY, 10); 

 
  }

}

  function mouseClicked(){
  //change screens 
   if(Math.abs(mouseX-20)<=15 && Math.abs(mouseY-20)<=15){
    r = 181;
    g = 232;
    b = 188;
 
   }
     if(Math.abs(mouseX-60)<=15 && Math.abs(mouseY-20)<=15){
    
       r = 237;
       g = 192; 
       b = 228;
    
  }
    if(Math.abs(mouseX-100)<=15 && Math.abs(mouseY-20)<=15){
    
       r = 193;
       g = 171; 
       b = 237;
    
  }
    if(Math.abs(mouseX-140)<=15 && Math.abs(mouseY-20)<=15){
       r = 171;
       g = 208; 
       b = 237;
  }
     if(Math.abs(mouseX-360)<=15 && Math.abs(mouseY-20)<=15){
       background(224, 204, 220);
       noStroke();
       fill(255, 255, 255);
       square(10, 10, 380);
  }
    if(Math.abs(mouseX-320)<=15 && Math.abs(mouseY-20)<=15){
       r = 255;
       g = 255; 
       b = 255;
  }
     if(Math.abs(mouseX-180)<=15 && Math.abs(mouseY-20)<=15){
       r = 245;
       g = 243; 
       b = 176;
  }
    if(Math.abs(mouseX-220)<=15 && Math.abs(mouseY-20)<=15){    
       r = 247;
       g = 173; 
       b = 146;
  }
    
  }