//jogo tipo sims com mini jogos 
//1 ecra: intro e escolher avatar 
// quinta e mini jogos 
//screen 4 = jogo intro 
let screen = 1; 
let intro;
let house; 
let houseint;
let lake;
let beach;
let name;
let inst; 
let houseInt;
let fish1;
let fish2;
let fant1;
let teddy;
let village;

let fishX1 = 100;
let fishY1 = 0;
let fishX2 = 350; 
let fishY2 = 0;
let speedX = 2;
let speedY = 1;
let scoreFish = 0;
let r = 0;
let g = 0;
let b = 0;
let livesFish = 3;

function setup() {
  createCanvas(600, 400);
  intro = loadImage('introscreen.jpg');
  house = loadImage('house.jpg');
  beach = loadImage('beach.jpg');
  main = loadImage('mainfront.png');
  lake = loadImage('lake.jpg')
  arrowLeft = loadImage('esquerda.png');
  arrowRight = loadImage('direita.png');
  fish1 = loadImage('fish1.png');
  fish2 = loadImage('fish2.png');
  name =loadImage('name.png');
  inst = loadImage('instrucoes.jpg');
  houseInt = loadImage('houseInterior.jpeg');
  fant1 = loadImage('game3.jpg');
  teddy = loadImage('teddybear1.jpg');
  village = loadImage('village.jpg');
  
}

function draw() {
  //Intro Screen
  if(screen == 1){
    imageMode(CORNER);
  image(intro, 0, 0, 600, 400);
  image(main, 390, 150, 150, 150);
  image(arrowLeft, 0, 170, 100, 100);
  image(arrowRight, 520, 170, 100, 100);
  image(name, 150, 60, 230, 150);
  textSize(15);
  fill(0, 0, 0);
  text("Clik the sign for instructions", 20, 30);
  }
  //outside House Screen
   if(screen == 2){
     imageMode(CORNER);
     image(house, 0, 0, 600, 400);
     image(main, 380, 200, 150, 150);
     image(arrowLeft, 0, 170, 100, 100);
     fill(127, 173, 142);
     rect(90, 30, 430, 50);
     textSize(20);
     fill(255, 255, 255);
     text("Click on the house to enter", 180, 60);
     
   }
  //Lake Screen
   if(screen == 3){
     imageMode(CORNER);
     image(beach, 0, 0, 600, 400);
     image(main, 395, 150, 150, 150);
     image(arrowRight, 520, 170, 100, 100);
     fill(127, 173, 142);
     rect(90, 30, 430, 50);
     textSize(20);
     fill(255, 255, 255);
     text("Click 'L' to play 'Fish the Fish'", 180, 60);
     
   }
  //Intro FishGame
  if(screen == 4){
    imageMode(CORNER);
    image(lake, 0, 0, 600, 400);
    fill(255, 255, 255);
    textSize(20);
    text("Click '1' to start playing", 390, 390);
    textSize(30);
    text("Welcome to 'Fish your Fish'", 130, 200);
    textSize(20);
    text("Use the mouse to catch your fish", 295, 370);
    textSize(20);
    text("Click 'i' to exit game", 400, 30);
  }
  //fishGame 
   if(screen == 5){
    imageMode(CENTER);
    image(lake, 300, 200, 600, 400);
    fill(255, 255, 255);
    textSize(20);
    text("Click 'i' to exit game", 400, 30);
    text("Score: " + scoreFish, 10, 30);
     text("Lives: " + livesFish, 10, 50);
    fill(r, g, b);
    ellipse(mouseX, mouseY, 30, 30);
    image(fish1, fishX1, fishY1, 150, 150);
    image(fish2, fishX2, fishY2, 100, 100);
     
    fishSpeed();
    wrapFish();
  }
   //fishGame last Screen
  if(screen == 6){
    imageMode(CENTER);
    image(lake, 300, 200, 600, 400);
    fill(255, 255, 255);
    textSize(20);
    text("Click 'i' to exit game", 400, 30);
    rect(90, 170, 430, 160);
    textSize(30);
    fill(182, 184, 123);
    text("You Lost. Better luck next time!", 100, 200);
    text("Score: " + scoreFish, 230, 250);
    text("Press '2' to play again", 150, 300);
  }
  //instructions screen
  if(screen == 7){
  image(intro, 0, 0, 600, 400);
  image(main, 390, 150, 150, 150);
  image(arrowLeft, 0, 170, 100, 100);
  image(arrowRight, 520, 170, 100, 100);
  image(inst, 110, 60, 400, 250);
  fill(0, 0, 0);
  textSize(15);
  text("Click 'x' to exit", 425, 25);
  
  }
  //inside the house
  if(screen ==8){
    imageMode(CORNER);
    image(houseInt, 0, 0, 600, 400);
    fill(255, 255, 255);
    textSize(15);
    text("Click 'Y' to exit", 480, 25);
    fill(255, 255, 255);
    rect(90, 30, 430, 50);
    textSize(20);
    fill(149, 191, 162);
    text("Click 'W' to play 'Doll House'", 180, 60);
     
  }
  //game inside House
  if(screen == 9){
    image(houseInt, 0, 0, 600, 400);
    fill(255, 255, 255);
    textSize(15);
    text("Click 'Y' to exit", 480, 25);fill(255, 255, 255);
    rect(90, 100, 430, 150);
    textSize(20);
    fill(149, 191, 162);
    text("Welcome to 'Doll House'", 200, 130);
    text("This is an escape game. Find the Teddy Bear.", 110, 160);
    text("Use the mouse to click on objects", 150, 190);
    text("Press '0' to start. Good Luck", 190, 230);
  }
  //Main Screen 2nd game
  if(screen == 10){
    imageMode(CORNER);
    image(fant1, 0, 0, 600, 400);
    fill(255, 255, 255);
    rect(470, 8, 120, 25);
    fill(0, 0, 0);
    textSize(15);
    text("Click 'Y' to exit", 480, 25);
    fill(189,154,122);
    ellipse(105, 250, 20, 20);
    ellipse(120, 150, 20, 20);
    ellipse(285, 180, 20, 20);
    ellipse(450, 200, 20, 20);
  }
  //stair Button
  if(screen == 11){
    baseGame();
    
    rect(90, 150, 430, 150);
    textSize(20);
    fill(247, 221, 181);
    text("A stair can lead to multiple places", 150, 210);
    text("or no where. Keep searching.", 170, 240);
    ellipse(500, 170, 30, 30);
    textSize(20);
    fill(189,154,122);
    text("X", 493, 177); 
  }
  //Button Picture 
  if(screen == 12){
    baseGame();
    
    //itself
    image(teddy, 150, 50, 300, 300);
    fill(247, 221, 181);
    ellipse(450, 50, 30, 30);
    textSize(20);
    fill(189,154,122);
    text("X", 445, 55); 
    
  }
  //found Teddy
  if(screen == 13){
    baseGame();
    
    rect(90, 150, 430, 150);
    textSize(20);
    fill(247, 221, 181);
    text("Congratulations!", 220, 210);
    text("You found the Teddy Bear.", 180, 240);
    fill(255, 255, 255);
    rect(470, 8, 120, 25);
    fill(0, 0, 0);
    textSize(15);
    text("Click 'Y' to exit", 480, 25);
  }
  //button window
  if(screen == 14){
    image(village, 0, 0, 600, 400);
    fill(107, 140, 116);
    rect(90, 300, 430, 70);
    textSize(20);
    fill(153, 194, 164);
    text("There is so much to explore outside", 150, 325);
    text("But what you are looking for is not here", 130, 350);
    ellipse(510, 310, 30, 30);
    textSize(20);
    fill(107, 140, 116);
    text("X", 503, 317); 
  }
  //button armors 
  if(screen == 15){
     baseGame();
    
    rect(90, 150, 430, 150);
    textSize(20);
    fill(247, 221, 181);
    text("Antiques are gorgeous.", 200, 210);
    text("Although Teddy Bears are not labelled as one", 110, 240);
    ellipse(500, 170, 30, 30);
    textSize(20);
    fill(189,154,122);
    text("X", 493, 177); 
  }
  
}

//fish game instrução de uso
function mousePressed(){
  if(Math.abs(mouseX-fishX1)<=90 && Math.abs(mouseY-fishY1)<=90){
    r = random(0,255);
    g = random(0,255);
    b = random(0,255);
    fishX1 = random(5, 345);
    fishY1 = 0;
    speedY = speedY + 0.1;
    scoreFish = scoreFish + 1;
  }
  if(Math.abs(mouseX-fishX2)<=90 && Math.abs(mouseY-fishY2)<=90){
    r = random(0,255);
    g = random(0,255);
    b = random(0,255);
    fishX2 = random(350, 570);
    fishY2 = 0;
    speedY = speedY + 0.1;
    scoreFish = scoreFish + 1;
  }
  //DOTS GAME 2
  //dot 1
  if(Math.abs(mouseX-105)<=10 && Math.abs(mouseY-250)<=10 && screen == 10){
   screen = 11;
  }
  
  //dot 2
  if(Math.abs(mouseX-120)<=10 && Math.abs(mouseY-150)<=10 && screen == 10){
   screen = 12;
  }
  
  //dot 3
  if(Math.abs(mouseX-285)<=10 && Math.abs(mouseY-180)<=10 && screen == 10){
   screen = 14;
  }
  
  //dot 4
  if(Math.abs(mouseX-450)<=10 && Math.abs(mouseY-200)<=10 && screen == 10){
   screen = 15;
  }
  
  //exit dot 1 
   if(Math.abs(mouseX-500)<=15 && Math.abs(mouseY-170)<=15 && screen == 11){
   screen = 10;
  }
  //exit dot 2
  if(Math.abs(mouseX-450)<=15 && Math.abs(mouseY-50)<=15 && screen == 12){
   screen = 10;
  }
  //exit dot 3
   if(Math.abs(mouseX-510)<=15 && Math.abs(mouseY-310)<=15 && screen == 14){
   screen = 10;
  } 
   //exit dot 4
   if(Math.abs(mouseX-500)<=15 && Math.abs(mouseY-170)<=15 && screen == 15){
   screen = 10;
  }
  
  //find Teddy
  if(Math.abs(mouseX-310)<=35/2 && Math.abs(mouseY-250)<=35/2 && screen == 12){
   screen = 13;
  }
 
}

//games 
 function keyPressed(){
   if(key == "l"){
     screen = 4;
   }
   if(key == "i"){
     screen = 3;
   }
   if(key == "1"){
     screen = 5;
   }
   if(key == "x"){
     screen = 1;
   }
   if(key == "y"){
     screen = 2;
   }
   if(key == "w"){
     screen = 9;
   }
   if(key == "2"){
     screen = 5;
     livesFish = 3;
     scoreFish = 0;
     speedX = 2;
     speedY = 1;
     fishX1 = 100;
     fishY1 = 0;
     fishX2 = 350; 
     fishY2 = 0;
     
   }
   if(key == "0"){
     screen = 10;
   }
   
 }


//mouse 

function mouseClicked(){
  //change screens 
 if(mouseX > 350 && mouseY > 200 && mouseY < 250 && screen == 1)
    {
      screen = 2;
    }
  
   if(mouseX > 350 && mouseY > 200 && mouseY < 250 && screen == 3)
    {
      screen = 1;
    } 
  
if(mouseX < 50 && mouseY > 200 && mouseY < 250 && screen == 1)
    {
      screen = 3;
    }
  
  if(mouseX < 50 && mouseY > 200 && mouseY < 250 && screen == 2)
    {
      screen = 1;
    }
  //getting inside house 
  if(mouseX< 400 && mouseX>200 && mouseY>50 && mouseY<300 && screen == 2){
    screen = 8;
  }
  
  //touch buttons menu
  if(mouseX>150 && mouseX<300 && mouseY>60 && mouseY<250 && screen == 1){
    screen = 7;
  }
}

function wrapFish(){
  
   if(fishY1 > 400 ){
      fishY1 = 0;
      fishX1 = random(5, 345);
      speedY = speedY + 0.2;
      livesFish = livesFish - 1;
    }
     if(fishY2 > 400){
      fishY2 = 0;
      fishX2 = random(350, 570);
      speedY = speedY + 0.2;
      livesFish = livesFish - 1;
    }
     
     if(livesFish == 0){
       screen = 6;
     } 
}

function fishSpeed(){
   fishY1 = fishY1 + speedY;
   fishY2 = fishY2 + speedY;
}

function baseGame(){
  imageMode(CORNER);
    image(fant1, 0, 0, 600, 400);
    fill(189,154,122);
    ellipse(105, 250, 20, 20);
    ellipse(120, 150, 20, 20);
    ellipse(285, 180, 20, 20);
    ellipse(450, 200, 20, 20);
}